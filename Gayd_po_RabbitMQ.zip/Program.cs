﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RabbitMQ.Client;
using RabbitMQ.Client.Content;
using RabbitMQ.Client.MessagePatterns;
using RabbitMQ.Client.Events;

namespace TestMQ
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ничего в конфиге не трогаем до отдельных указаний
            ConnectionFactory factory = new ConnectionFactory();
            factory.UserName = "tester";
            factory.Password = "tester";
            factory.VirtualHost = "/";
            factory.HostName = "airport-dko-1.cloudapp.net";
            factory.Port = 5672;
            // ********************

            IConnection connection = factory.CreateConnection();
            IModel channel = connection.CreateModel();


            // Декларируем имя очереди, вместо TestQueue укажите правильную очереди, имена очередей обсудим дополнительно
            // Не срите в чужое очко, имейте уважение
            channel.QueueDeclare("TestQueue", false, false, false, null);
            // ********************


            // Передача сообщения в очередь
            string message = "Privet YOBA"; // что передаем
            var body = Encoding.UTF8.GetBytes(message); // декодируем в UTF8, хз можно ли без этого

            channel.BasicPublish("", "TestQueue", null, body); // И ТУТ МЕНЯЕМ НАЗВАНИЕ ОЧЕРЕДИ
            Console.WriteLine("Отправлено сообщение {0}", message); // если что, оно будет выдано, даже если ничего не отправится
            // ********************


            // Чтение сообщений из очереди
            var consumer = new QueueingBasicConsumer(channel);
            channel.BasicConsume("TestQueue", true, consumer);  // И ТУТ МЕНЯЕМ НАЗВАНИЕ ОЧЕРЕДИ

            Console.WriteLine("[*] Ждем сообщений. " + "CTRL+C, если заебало");

            while (true)
            {
                var ea = (BasicDeliverEventArgs)consumer.Queue.Dequeue();

                var body_read = ea.Body;
                var message_read = Encoding.UTF8.GetString(body_read);
                Console.WriteLine("Получено сообщение: {0}", message_read);
            }
            // ********************
        }
    }
}
